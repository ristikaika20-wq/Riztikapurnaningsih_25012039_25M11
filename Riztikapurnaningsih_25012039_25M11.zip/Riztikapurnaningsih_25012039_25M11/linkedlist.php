<?php
session_start();
class Node {
    public string $data; public ?Node $next = null;
    public function __construct(string $data){$this->data=$data;}
}
class LinkedList {
    private ?Node $head=null;
    public function insertFirst(string $data):void{$n=new Node($data);$n->next=$this->head;$this->head=$n;}
    public function insertLast(string $data):void{
        $n=new Node($data); if($this->head===null){$this->head=$n;return;}
        $c=$this->head; while($c->next!==null)$c=$c->next; $c->next=$n;
    }
    public function delete(string $data):bool{
        if($this->head===null)return false;
        if($this->head->data===$data){$this->head=$this->head->next;return true;}
        $c=$this->head; while($c->next!==null){if($c->next->data===$data){$c->next=$c->next->next;return true;}$c=$c->next;} return false;
    }
    public function toArray():array{$r=[];$c=$this->head;while($c!==null){$r[]=$c->data;$c=$c->next;}return $r;}
}
if(!isset($_SESSION['linked_data']))$_SESSION['linked_data']=["Node A","Node B","Node C"];
$message="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
    $action=$_POST["action"]??"";$value=trim($_POST["value"]??"");
    $list=new LinkedList();foreach($_SESSION['linked_data'] as $item)$list->insertLast($item);
    if(($action==="first"||$action==="last")&&$value!==""){
        if($action==="first"){$list->insertFirst($value);$message="\"$value\" ditambahkan di awal Linked List.";}
        else{$list->insertLast($value);$message="\"$value\" ditambahkan di akhir Linked List.";}
    }elseif($action==="delete"&&$value!=="")$message=$list->delete($value)?"\"$value\" berhasil dihapus.":"\"$value\" tidak ditemukan.";
    elseif($action==="reset"){$list=new LinkedList();$list->insertLast("Node A");$list->insertLast("Node B");$list->insertLast("Node C");$message="Linked List direset.";}
    elseif(in_array($action,["first","last","delete"])&&$value==="")$message="Masukkan nama node terlebih dahulu.";
    $_SESSION['linked_data']=$list->toArray();
}
$data=$_SESSION['linked_data'];
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Demo Linked List</title><link rel="stylesheet" href="style.css"></head>
<body><header class="topbar"><div class="container nav"><a href="index.php">← Beranda</a><strong>Demo Linked List</strong></div></header>
<main class="container page"><span class="badge">STRUKTUR 02</span><h1>Linked List</h1><p>Linked List terdiri dari node. Setiap node menyimpan data dan referensi menuju node berikutnya.</p>
<?php if($message):?><div class="alert"><?=htmlspecialchars($message)?></div><?php endif;?>
<section class="card"><h2>Visualisasi Node</h2><div class="linked-view">
<?php foreach($data as $i=>$value):?><div class="node"><span>Node <?=$i+1?></span><strong><?=htmlspecialchars($value)?></strong><small>next →</small></div><?php if($i<count($data)-1):?><div class="arrow">→</div><?php endif;?><?php endforeach;?>
<?php if(!$data):?><p class="empty">Linked List kosong.</p><?php endif;?></div><div class="head-label">HEAD → <?=$data?htmlspecialchars($data[0]):"NULL"?></div></section>
<section class="grid two"><div class="card"><h2>Operasi Linked List</h2><form method="post" class="form"><label>Nama node</label><input type="text" name="value" placeholder="Contoh: Node D">
<div class="button-row"><button class="button" name="action" value="first">Tambah di Awal</button><button class="button" name="action" value="last">Tambah di Akhir</button><button class="danger" name="action" value="delete">Hapus Node</button></div></form></div>
<div class="card"><h2>Cara Kerja</h2><ol class="steps"><li><b>HEAD</b> menunjuk node pertama.</li><li>Node mempunyai <b>data</b> dan <b>next</b>.</li><li>Program berjalan dari HEAD saat mencari node.</li><li>Penghapusan mengubah hubungan <b>next</b>.</li></ol><form method="post"><input type="hidden" name="action" value="reset"><button class="secondary">Reset Linked List</button></form></div></section>
</main><footer>Demo Linked List • Riztika Purnaningsih</footer></body></html>
