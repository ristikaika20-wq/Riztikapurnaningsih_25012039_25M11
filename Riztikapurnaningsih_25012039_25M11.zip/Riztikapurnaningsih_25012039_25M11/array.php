<?php
session_start();
if (!isset($_SESSION['array_data'])) $_SESSION['array_data'] = ["Apel","Jeruk","Mangga"];
$message = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST["action"] ?? "";
    if ($action === "add") {
        $value = trim($_POST["value"] ?? "");
        if ($value !== "") { $_SESSION['array_data'][] = $value; $message = "Data \"$value\" berhasil ditambahkan."; }
        else $message = "Masukkan data terlebih dahulu.";
    } elseif ($action === "delete") {
        $index = filter_input(INPUT_POST,"index",FILTER_VALIDATE_INT);
        if ($index !== false && $index !== null && isset($_SESSION['array_data'][$index])) {
            $deleted = $_SESSION['array_data'][$index]; array_splice($_SESSION['array_data'],$index,1);
            $message = "Data \"$deleted\" pada indeks $index berhasil dihapus.";
        } else $message = "Indeks tidak ditemukan.";
    } elseif ($action === "reset") {
        $_SESSION['array_data'] = ["Apel","Jeruk","Mangga"]; $message = "Array dikembalikan ke kondisi awal.";
    }
}
$data = $_SESSION['array_data'];
?>
<!DOCTYPE html><html lang="id"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Demo Array</title><link rel="stylesheet" href="style.css"></head>
<body><header class="topbar"><div class="container nav"><a href="index.php">← Beranda</a><strong>Demo Array</strong></div></header>
<main class="container page"><span class="badge">STRUKTUR 01</span><h1>Linear Array</h1>
<p>Array menyimpan elemen secara berurutan dan setiap elemen dapat diakses menggunakan indeks.</p>
<?php if ($message): ?><div class="alert"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<section class="card"><h2>Array Saat Ini</h2><div class="array-view">
<?php foreach ($data as $index=>$value): ?><div class="array-item"><span class="index">Index <?= $index ?></span><strong><?= htmlspecialchars($value) ?></strong>
<form method="post"><input type="hidden" name="action" value="delete"><input type="hidden" name="index" value="<?= $index ?>"><button class="danger small">Hapus</button></form></div><?php endforeach; ?>
</div><?php if (!$data): ?><p class="empty">Array kosong.</p><?php endif; ?></section>
<section class="grid two"><div class="card"><h2>Tambah Elemen</h2><form method="post" class="form">
<input type="hidden" name="action" value="add"><label>Nilai baru</label><input type="text" name="value" placeholder="Contoh: Pisang" required><button class="button">+ Tambah ke Array</button></form></div>
<div class="card"><h2>Cara Kerja</h2><ol class="steps"><li>Indeks dimulai dari <b>0</b>.</li><li>Data ditambahkan dengan <code>$array[] = $data</code>.</li><li>Penghapusan berdasarkan indeks menggunakan <code>array_splice()</code>.</li></ol>
<form method="post"><input type="hidden" name="action" value="reset"><button class="secondary">Reset Array</button></form></div></section>
</main><footer>Demo Array • Riztika Purnaningsih</footer></body></html>
