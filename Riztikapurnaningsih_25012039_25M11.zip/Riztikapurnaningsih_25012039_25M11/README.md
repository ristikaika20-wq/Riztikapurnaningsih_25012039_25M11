# Riztikapurnaningsih_25012039_25M11

Project PHP untuk mengimplementasikan dan memvisualisasikan tiga struktur data linear secara interaktif:

- **Array**
- **Linked List**
- **Stack (LIFO)**

## Identitas
- Nama: Riztika Purnaningsih
- NIM: 25012039
- Kelas: 25M11

## Fitur
- Halaman utama project.
- Demo Array: tambah, hapus berdasarkan indeks, dan reset.
- Demo Linked List: tambah node di awal/akhir, hapus node, dan reset.
- Demo Stack: Push, Pop, dan reset.
- Visualisasi sederhana cara kerja setiap struktur data.
- PHP Session digunakan untuk menyimpan data selama sesi.

## Menjalankan dengan XAMPP

1. Jalankan Apache pada XAMPP.
2. Letakkan folder `Riztikapurnaningsih_25012039_25M11` di `C:\xampp\htdocs\`.
3. Buka:

`http://localhost/Riztikapurnaningsih_25012039_25M11/`

## Menjalankan dengan PHP Built-in Server

Buka terminal di folder project:

```bash
php -S localhost:8000
```

Kemudian buka `http://localhost:8000`.

## Struktur File

```text
Riztikapurnaningsih_25012039_25M11/
├── index.php
├── array.php
├── linkedlist.php
├── stack.php
├── style.css
└── README.md
```

## Deskripsi GitHub

> Project PHP interaktif yang mengimplementasikan tiga struktur data linear, yaitu Array, Linked List, dan Stack. Project ini menampilkan cara kerja dan operasi dasar setiap struktur data melalui halaman web interaktif.
