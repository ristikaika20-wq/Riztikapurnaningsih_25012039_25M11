<?php
session_start();
if(!isset($_SESSION['stack_data']))$_SESSION['stack_data']=["Buku","Laptop","Kamera"];
$message="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
    $action=$_POST["action"]??"";
    if($action==="push"){$value=trim($_POST["value"]??"");if($value!==""){$_SESSION['stack_data'][]=$value;$message="\"$value\" masuk ke TOP Stack (Push).";}else$message="Masukkan data terlebih dahulu.";}
    elseif($action==="pop"){if($_SESSION['stack_data']){$removed=array_pop($_SESSION['stack_data']);$message="\"$removed\" keluar dari TOP Stack (Pop).";}else$message="Stack kosong.";}
    elseif($action==="reset"){$_SESSION['stack_data']=["Buku","Laptop","Kamera"];$message="Stack dikembalikan ke kondisi awal.";}
}
$stack=$_SESSION['stack_data'];
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Demo Stack</title><link rel="stylesheet" href="style.css"></head>
<body><header class="topbar"><div class="container nav"><a href="index.php">← Beranda</a><strong>Demo Stack</strong></div></header>
<main class="container page"><span class="badge">STRUKTUR 03</span><h1>Stack — LIFO</h1><p>Stack menggunakan prinsip <b>Last In, First Out</b>: data terakhir masuk akan keluar terlebih dahulu.</p>
<?php if($message):?><div class="alert"><?=htmlspecialchars($message)?></div><?php endif;?>
<section class="grid two"><div class="card"><h2>Visualisasi Stack</h2><div class="stack-box"><div class="top-label">TOP</div>
<?php for($i=count($stack)-1;$i>=0;$i--):?><div class="stack-item <?=($i===count($stack)-1?'top-item':'')?>"><span><?=$i?></span><strong><?=htmlspecialchars($stack[$i])?></strong><?php if($i===count($stack)-1):?><small>← keluar pertama</small><?php endif;?></div><?php endfor;?>
<?php if(!$stack):?><p class="empty">Stack kosong.</p><?php endif;?></div></div>
<div class="card"><h2>Operasi Stack</h2><form method="post" class="form"><label>Data baru</label><input type="text" name="value" placeholder="Contoh: Mouse">
<button class="button" name="action" value="push">⬆ Push</button><button class="danger" name="action" value="pop">⬇ Pop</button><button class="secondary" name="action" value="reset">Reset Stack</button></form>
<div class="formula"><b>LIFO</b><br>Last In → First Out</div></div></section>
<section class="card"><h2>Contoh Urutan</h2><p>Jika dilakukan <b>Push A → Push B → Push C</b>, maka urutan Pop adalah <b>C → B → A</b>.</p><div class="sequence"><span>Push A</span><span>→</span><span>Push B</span><span>→</span><span>Push C</span><span>→</span><span>Pop C</span></div></section>
</main><footer>Demo Stack • Riztika Purnaningsih</footer></body></html>
