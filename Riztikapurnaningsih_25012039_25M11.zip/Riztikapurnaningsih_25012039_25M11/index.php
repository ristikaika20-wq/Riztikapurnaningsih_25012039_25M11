<?php session_start(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Struktur Data Linear - Riztika Purnaningsih</title><link rel="stylesheet" href="style.css">
</head>
<body>
<header class="hero"><div class="container">
<span class="badge">PROJECT PHP • STRUKTUR DATA</span>
<h1>Struktur Data Linear</h1>
<p>Demo interaktif Array, Linked List, dan Stack menggunakan PHP.</p>
<p class="student">Riztika Purnaningsih • 25012039 • 25M11</p>
</div></header>
<main class="container">
<section class="card intro"><h2>Selamat Datang 👋</h2>
<p>Project ini memperlihatkan cara kerja tiga struktur data linear melalui halaman web interaktif.</p></section>
<section class="grid">
<a class="data-card card" href="array.php"><div class="icon">📦</div><h2>Array</h2><p>Menyimpan beberapa data dalam satu variabel berdasarkan indeks.</p><span class="button">Buka Demo →</span></a>
<a class="data-card card" href="linkedlist.php"><div class="icon">🔗</div><h2>Linked List</h2><p>Data disimpan sebagai node yang saling terhubung melalui pointer.</p><span class="button">Buka Demo →</span></a>
<a class="data-card card" href="stack.php"><div class="icon">📚</div><h2>Stack</h2><p>Menggunakan prinsip LIFO: data terakhir masuk adalah yang pertama keluar.</p><span class="button">Buka Demo →</span></a>
</section>
<section class="card"><h2>Perbandingan Singkat</h2>
<table><tr><th>Struktur</th><th>Konsep</th><th>Operasi Demo</th></tr>
<tr><td>Array</td><td>Indeks</td><td>Tambah, hapus, reset</td></tr>
<tr><td>Linked List</td><td>Node → Node</td><td>Tambah awal/akhir, hapus</td></tr>
<tr><td>Stack</td><td>LIFO</td><td>Push dan Pop</td></tr></table>
</section>
</main><footer>© 2026 Riztika Purnaningsih — Project Struktur Data Linear</footer>
</body></html>
